package com.javalec.base;

public class Main {

	public static void main(String[] args) {
        /*
         *  아래의 문장은 화면에 출력하는 문장 입니다 
         */
		System.out.println("1234");        
		System.out.println("1234");
	
	}

}

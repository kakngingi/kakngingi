package com.javalec.base;

public class Main {

}

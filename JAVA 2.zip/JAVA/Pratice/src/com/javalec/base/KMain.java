package com.javalec.base;

import java.util.Scanner;

public class KMain {

	public static void main(String[] args) {
		//스캐너 생성
		Scanner scanner = new scanner(System.in);
		
		//입력받을 변수, 합계, 평균, 카운트
		int startNum = 0;
		int lastNum = 0;
		int sum = 0;
		int evenSum = 0;
		int oddSum = 0;
		
		
		//입력 받기
		System.out.print("덧셈 시작 수를 입력 : ");
		startNum = scanner.nextInt();
		System.out.print("마지막 수를 입력 : ");
		lastNum = scanner.nextInt();
		
		
		
		
	}
	

}

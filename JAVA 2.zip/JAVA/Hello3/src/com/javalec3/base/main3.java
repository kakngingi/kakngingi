package com.javalec3.base;

public class main3 {

	public static void main(String[] args) {
		/*
		 * 아래의 문장은 설명문입니
		 */
		System.out.println("Hello word!");

	}

}

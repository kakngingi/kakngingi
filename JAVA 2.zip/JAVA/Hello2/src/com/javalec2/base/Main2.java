package com.javalec2.base;

public class Main2 {

	public static void main(String[] args) {
		/*
		 * 아래의 문장은 화면에 출력하는 문장 입니다.
		 */
		System.out.println("Hello word!");
		System.out.println("Hello word!");
	}

}
